git add .
git commit -am $1
git pull

git commit -am $1+'version1'
git push
